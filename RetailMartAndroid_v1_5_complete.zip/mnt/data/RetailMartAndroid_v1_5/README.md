# Retail Mart Android App v1.5

यह Android grocery/retail billing app project है।

## मुख्य सुविधाएँ
- सामान जोड़ना, खोजना और stock
- बिक्री/cart और cash/partial payment
- ग्राहक और उधार balance
- बिक्री history और reports
- PDF bill खोलना और share करना
- JSON backup/share
- डेटा Room database में local रूप से save होता है

## APK बनाना
Android Studio में project folder खोलें और Gradle sync होने के बाद:
**Build → Build APK(s)**

Debug APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनता है।

नोट: इस source package में Android SDK/Gradle binaries शामिल नहीं हैं।
