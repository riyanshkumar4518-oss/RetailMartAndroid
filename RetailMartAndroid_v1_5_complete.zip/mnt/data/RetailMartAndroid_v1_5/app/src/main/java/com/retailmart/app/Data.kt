package com.retailmart.app

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Product(@PrimaryKey(autoGenerate = true) val id:Int=0, val name:String, val price:Double, val stock:Int)

@Entity
data class Customer(@PrimaryKey(autoGenerate = true) val id:Int=0, val name:String, val phone:String, val balance:Double=0.0)

@Entity
data class Sale(@PrimaryKey(autoGenerate = true) val id:Int=0, val total:Double, val paid:Double, val customerId:Int?, val date:String)

@Dao
interface ProductDao {
    @Query("SELECT * FROM Product ORDER BY name") fun observeAll(): Flow<List<Product>>
    @Insert suspend fun insert(p:Product)
    @Update suspend fun update(p:Product)
}
@Dao
interface CustomerDao {
    @Query("SELECT * FROM Customer ORDER BY name") fun observeAll(): Flow<List<Customer>>
    @Insert suspend fun insert(c:Customer)
    @Update suspend fun update(c:Customer)
}
@Dao
interface SaleDao {
    @Query("SELECT * FROM Sale ORDER BY id DESC") fun observeAll(): Flow<List<Sale>>
    @Insert suspend fun insert(s:Sale)
}

@Database(entities=[Product::class,Customer::class,Sale::class],version=1,exportSchema=false)
abstract class RetailDatabase:RoomDatabase(){
    abstract fun productDao():ProductDao
    abstract fun customerDao():CustomerDao
    abstract fun saleDao():SaleDao
    companion object {
        @Volatile private var INSTANCE:RetailDatabase?=null
        fun get(context:android.content.Context):RetailDatabase =
            INSTANCE ?: synchronized(this){
                INSTANCE ?: Room.databaseBuilder(context.applicationContext,RetailDatabase::class.java,"retail_mart.db")
                    .fallbackToDestructiveMigration().build().also{INSTANCE=it}
            }
    }
}
