package com.retailmart.app

import android.os.Bundle
import android.content.Intent
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.*
import kotlinx.coroutines.flow.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.*

data class CartItem(val product:Product,val quantity:Int)

class RetailVM(private val db:RetailDatabase):ViewModel(){
    val products=db.productDao().observeAll()
    val customers=db.customerDao().observeAll()
    val sales=db.saleDao().observeAll()
    private val _cart=MutableStateFlow<List<CartItem>>(emptyList())
    val cart:StateFlow<List<CartItem>>=_cart

    fun addProduct(n:String,p:Double,s:Int)=viewModelScope.launch{db.productDao().insert(Product(name=n,price=p,stock=s))}
    fun addCustomer(n:String,phone:String)=viewModelScope.launch{db.customerDao().insert(Customer(name=n,phone=phone))}
    fun addToCart(p:Product)=viewModelScope.launch{
        if(p.stock<=0)return@launch
        val c=_cart.value.toMutableList(); val i=c.indexOfFirst{it.product.id==p.id}
        if(i>=0)c[i]=c[i].copy(quantity=c[i].quantity+1) else c.add(CartItem(p,1))
        _cart.value=c; db.productDao().update(p.copy(stock=p.stock-1))
    }
    fun checkout(customer:Customer?, paid:Double, items:List<CartItem>, onDone:(Sale)->Unit)=viewModelScope.launch{
        val total=items.sumOf{it.product.price*it.quantity}; if(total<=0)return@launch
        val due=(total-paid).coerceAtLeast(0.0)
        if(customer!=null && due>0) db.customerDao().update(customer.copy(balance=customer.balance+due))
        val sale=Sale(total=total,paid=paid,customerId=customer?.id,
            date=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date()))
        val id=db.saleDao().insert(sale).toInt()
        _cart.value=emptyList()
        onDone(sale.copy(id=id))
    }
}
class VMFactory(private val db:RetailDatabase):ViewModelProvider.Factory{
    override fun <T:ViewModel> create(c:Class<T>):T{@Suppress("UNCHECKED_CAST") return RetailVM(db) as T}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm:RetailVM){
    val context = LocalContext.current

    val products by vm.products.collectAsStateWithLifecycle(initialValue=emptyList())
    val customers by vm.customers.collectAsStateWithLifecycle(initialValue=emptyList())
    val sales by vm.sales.collectAsStateWithLifecycle(initialValue=emptyList())
    val cart by vm.cart.collectAsStateWithLifecycle()
    var screen by remember{mutableStateOf("sale")}
    var search by remember{mutableStateOf("")}
    var customerId by remember{mutableStateOf<Int?>(null)}; var lastSale by remember{mutableStateOf<Sale?>(null)}
    var lastSaleItems by remember{mutableStateOf<List<CartItem>>(emptyList())}
    var paid by remember{mutableStateOf("")}
    var n by remember{mutableStateOf("")}; var p by remember{mutableStateOf("")}; var s by remember{mutableStateOf("")}
    var cn by remember{mutableStateOf("")}; var cp by remember{mutableStateOf("")}
    val total=cart.sumOf{it.product.price*it.quantity}
    val selected=customers.firstOrNull{it.id==customerId}
    Scaffold(topBar={TopAppBar(title={Text("Retail Mart")})}){pad->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                Button({screen="sale"}){Text("बिक्री")}
                Button({screen="stock"}){Text("स्टॉक")}
                Button({screen="customers"}){Text("ग्राहक")}
                Button({screen="history"}){Text("हिस्ट्री")}
                Button({screen="report"}){Text("रिपोर्ट")}
                Button({screen="backup"}){Text("बैकअप")}
            }
            Spacer(Modifier.height(10.dp))
            when(screen){
                "sale"->{
                    OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),label={Text("सामान खोजें")})
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){
                        items(products.filter{it.name.contains(search,true)}){x->
                            Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){
                                Column(Modifier.weight(1f)){Text(x.name);Text("SAR %.2f • स्टॉक %d".format(x.price,x.stock))}
                                Button({vm.addToCart(x)},enabled=x.stock>0){Text("+")}
                            }}
                        }
                    }
                    HorizontalDivider()
                    Text("कुल: SAR %.2f".format(total))
                    if(customers.isNotEmpty()){
                        Text("ग्राहक चुनें:")
                        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                            customers.take(4).forEach{c->Button({customerId=c.id}){Text(c.name.take(8))}}
                        }
                    }
                    OutlinedTextField(paid,{paid=it},Modifier.fillMaxWidth(),label={Text("प्राप्त राशि (SAR)")})
                    Text(if(selected!=null)"उधार शेष: SAR %.2f".format((total-(paid.toDoubleOrNull()?:0.0)).coerceAtLeast(0.0)) else "कैश बिक्री")
                    Spacer(Modifier.height(5.dp))
if (lastSale != null) {
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            Button({
                                val f = createReceiptPdf(context, lastSale!!, selected, lastSaleItems)
                                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                val send = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, "application/pdf")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(send)
                            }) { Text("PDF") }
                            Button({
                                val f = createReceiptPdf(context, lastSale!!, selected, lastSaleItems)
                                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(send, "बिल शेयर करें"))
                            }) { Text("शेयर") }
                        }
                    }
                    Button({
                        val pay = paid.toDoubleOrNull() ?: 0.0
                        val itemsForSale = cart
                        vm.checkout(selected,pay,itemsForSale){ sale ->
                            lastSale = sale
                            lastSaleItems = itemsForSale
                        }
                        paid=""; customerId=null
                    },Modifier.fillMaxWidth(),enabled=cart.isNotEmpty()){Text("बिक्री पूरी करें")}
                }
                "stock"->{
                    Text("स्टॉक",style=MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(n,{n=it},Modifier.fillMaxWidth(),label={Text("सामान")})
                    OutlinedTextField(p,{p=it},Modifier.fillMaxWidth(),label={Text("कीमत SAR")})
                    OutlinedTextField(s,{s=it},Modifier.fillMaxWidth(),label={Text("मात्रा")})
                    Button({val a=p.toDoubleOrNull();val b=s.toIntOrNull();if(n.isNotBlank()&&a!=null&&b!=null){vm.addProduct(n,a,b);n="";p="";s=""}},Modifier.fillMaxWidth()){Text("सामान सेव करें")}
                    LazyColumn{items(products){x->Text("${x.name} — स्टॉक ${x.stock}",Modifier.padding(7.dp))}}
                }
                "customers"->{
                    Text("ग्राहक और उधार",style=MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(cn,{cn=it},Modifier.fillMaxWidth(),label={Text("ग्राहक का नाम")})
                    OutlinedTextField(cp,{cp=it},Modifier.fillMaxWidth(),label={Text("फोन")})
                    Button({if(cn.isNotBlank()){vm.addCustomer(cn,cp);cn="";cp=""}},Modifier.fillMaxWidth()){Text("ग्राहक सेव करें")}
                    Spacer(Modifier.height(8.dp))
                    LazyColumn{items(customers){c->Card(Modifier.fillMaxWidth().padding(4.dp)){Column(Modifier.padding(10.dp)){Text(c.name);Text(c.phone);Text("उधार: SAR %.2f".format(c.balance))}}}}
                }
                "history"->{
                    Text("बिक्री हिस्ट्री",style=MaterialTheme.typography.headlineSmall)
                    LazyColumn{items(sales){x->Card(Modifier.fillMaxWidth().padding(4.dp)){Column(Modifier.padding(10.dp)){Text("बिल #${x.id}");Text("कुल SAR %.2f • भुगतान %.2f".format(x.total,x.paid));Text(x.date)}}}}
                }

                "report"->{
                    val totalSales = sales.sumOf{it.total}
                    val totalPaid = sales.sumOf{it.paid}
                    val totalDue = (totalSales-totalPaid).coerceAtLeast(0.0)
                    Text("बिक्री रिपोर्ट",style=MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(10.dp))
                    Card(Modifier.fillMaxWidth()){
                        Column(Modifier.padding(16.dp)){
                            Text("कुल बिल: ${sales.size}")
                            Text("कुल बिक्री: SAR %.2f".format(totalSales))
                            Text("कुल प्राप्त: SAR %.2f".format(totalPaid))
                            Text("उधार/बाकी: SAR %.2f".format(totalDue))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("स्टॉक में उत्पाद: ${products.size}")
                    Text("कुल स्टॉक यूनिट: ${products.sumOf{it.stock}}")
                }
                "backup"->{
                    Text("डेटा बैकअप",style=MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    Text("सामान, ग्राहक और बिक्री का JSON बैकअप बनाया जा सकता है।")
                    Spacer(Modifier.height(8.dp))
                    Button({
                        val f=createBackupJson(context,products,customers,sales)
                        val send=Intent(Intent.ACTION_SEND).apply{
                            type="application/json"
                            putExtra(Intent.EXTRA_TEXT,f.readText())
                        }
                        context.startActivity(Intent.createChooser(send,"बैकअप शेयर करें"))
                    },Modifier.fillMaxWidth()){Text("बैकअप बनाएं और शेयर करें")}
                    Spacer(Modifier.height(8.dp))
                    Text("प्रिंटर: अगला चरण ESC/POS थर्मल प्रिंटर के लिए Bluetooth/USB सपोर्ट जोड़ेगा।")
                }
            }
        }
    }
}


fun createBackupJson(context: android.content.Context, products: List<Product>, customers: List<Customer>, sales: List<Sale>): File {
    val json = org.json.JSONObject()
    val pa = org.json.JSONArray()
    products.forEach { x -> pa.put(org.json.JSONObject().apply {
        put("id", x.id); put("name", x.name); put("price", x.price); put("stock", x.stock)
    }) }
    val ca = org.json.JSONArray()
    customers.forEach { x -> ca.put(org.json.JSONObject().apply {
        put("id", x.id); put("name", x.name); put("phone", x.phone); put("balance", x.balance)
    }) }
    val sa = org.json.JSONArray()
    sales.forEach { x -> sa.put(org.json.JSONObject().apply {
        put("id", x.id); put("total", x.total); put("paid", x.paid)
        put("customerId", x.customerId); put("date", x.date)
    }) }
    json.put("products", pa); json.put("customers", ca); json.put("sales", sa)
    val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "RetailMart_Backup.json")
    file.writeText(json.toString(2), Charsets.UTF_8)
    return file
}

fun createReceiptPdf(context: android.content.Context, sale: Sale, customer: Customer?, items: List<CartItem>): File {
    val doc = PdfDocument()
    val page = doc.startPage(PdfDocument.PageInfo.Builder(384, 620, 1).create())
    val c = page.canvas
    val paint = android.graphics.Paint().apply { textSize = 14f }
    var y = 28f
    c.drawText("RETAIL MART", 120f, y, paint); y += 24
    c.drawText("बिक्री बिल #${sale.id}", 20f, y, paint); y += 20
    c.drawText(sale.date, 20f, y, paint); y += 24
    if (customer != null) { c.drawText("ग्राहक: ${customer.name}", 20f, y, paint); y += 20 }
    items.forEach {
        c.drawText("${it.product.name} x${it.quantity}", 20f, y, paint)
        c.drawText("%.2f".format(it.product.price * it.quantity), 285f, y, paint)
        y += 20
    }
    y += 8
    c.drawText("कुल: SAR %.2f".format(sale.total), 20f, y, paint); y += 20
    c.drawText("भुगतान: SAR %.2f".format(sale.paid), 20f, y, paint); y += 20
    c.drawText("धन्यवाद!", 20f, y, paint)
    doc.finishPage(page)
    val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!
    val file = File(dir, "RetailMart_Bill_${sale.id}.pdf")
    FileOutputStream(file).use { doc.writeTo(it) }
    doc.close()
    return file
}

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);val db=RetailDatabase.get(this);setContent{val vm:RetailVM=viewModel(factory=VMFactory(db));App(vm)}}
}
